import helloWorld from './hello-world.js';
import addImage from './add-image.js';

helloWorld();
addImage();
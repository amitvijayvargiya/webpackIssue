function helloWorld(){
    console.log("Hello World");
}

export default helloWorld;